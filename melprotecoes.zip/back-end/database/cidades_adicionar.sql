INSERT INTO `cidades` (`id`, `nome`, `id_estado_fk`) VALUES
(5565, 'Zona Leste', 26),
(5566, 'Zona Oeste', 26),
(5567, 'Zona Sul', 26),
(5568, 'Zona Norte', 26),
(5569, 'Centro São Paulo', 26),
(5570, 'Interiro São Paulo', 26),
(5571, 'Litoral São Paulo', 26),
(5572, 'Guarulhos', 26),
